#include <stdio.h>
int main() {
    int a=1; int b=2; int c=1;
    int x;
    scanf("%d",&x);
    int doublee = x*x;
    int equation = a*doublee + b*x + c;
    printf("%d",equation);
    return 0;
    
}