#include <stdio.h>
float main() {
    float a=1; float b=2; float c=1;
    float x;
    scanf("%f",&x);
    float doublee = x*x;
    float equation = a*doublee + b*x + c;
    printf("%f",equation);
    return 0;
    
}